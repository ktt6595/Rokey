#!/usr/bin/env python3
"""
ROS2와 Firebase 연동 스크립트
UI에서 명령을 받아 ROS2 노드를 제어하고, 상태를 Firebase에 업데이트합니다.
"""

import time
import subprocess
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import threading
import signal
import sys


# ========================================
# Firebase 설정
# ========================================
SERVICE_ACCOUNT_KEY_PATH = "/home/rokey/cobot_ws/src/ui_node/ui_node/cocooker-firebase-adminsdk-fbsvc-54e63b03c6.json"  # 여기에 실제 JSON 키 파일 경로 입력
DATABASE_URL = "https://cocooker-default-rtdb.asia-southeast1.firebasedatabase.app/"  # Firebase URL

# Firebase 초기화
try:
    cred = credentials.Certificate(SERVICE_ACCOUNT_KEY_PATH)
    firebase_admin.initialize_app(cred, {
        'databaseURL': DATABASE_URL
    })
    print("✅ Firebase 초기화 완료")
except ValueError:
    print("⚠️ Firebase 앱이 이미 초기화되었습니다.")
except Exception as e:
    print(f"❌ Firebase 초기화 실패: {e}")
    sys.exit(1)


# ========================================
# ROS2 프로세스 관리
# ========================================
class ROS2ProcessManager:
    def __init__(self):
        self.process = None
        self.is_running = False
        
    def start(self, package_name, executable_name):
        """ROS2 노드 시작"""
        if self.is_running:
            print("⚠️ 프로세스가 이미 실행 중입니다.")
            return False
        
        try:
            # ROS2 실행 명령
            cmd = ['ros2', 'run', package_name, executable_name]
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.is_running = True
            print(f"✅ ROS2 프로세스 시작: {package_name} {executable_name} (PID: {self.process.pid})")
            
            # Firebase에 상태 업데이트
            update_status("실행 중", "running")
            update_current_object("초기화 중...")
            
            return True
        except Exception as e:
            print(f"❌ 프로세스 시작 실패: {e}")
            update_status("오류", "error")
            return False
    
    def stop(self):
        """ROS2 노드 중지"""
        if not self.is_running or self.process is None:
            print("⚠️ 실행 중인 프로세스가 없습니다.")
            return False
        
        try:
            self.process.terminate()
            self.process.wait(timeout=5)
            self.is_running = False
            print("✅ 프로세스 정상 종료")
            
            update_status("대기 중", "")
            update_current_object("중지 완료")
            return True
        except subprocess.TimeoutExpired:
            print("⚠️ 정상 종료 실패, 강제 종료 시도...")
            self.process.kill()
            self.is_running = False
            update_status("강제 종료", "error")
            return True
        except Exception as e:
            print(f"❌ 프로세스 종료 실패: {e}")
            return False
    
    def emergency_stop(self):
        """비상정지"""
        if self.process:
            try:
                self.process.kill()
                self.is_running = False
                print("🚨 비상정지 실행")
                update_status("비상정지", "error")
                update_current_object("비상정지 완료")
                return True
            except Exception as e:
                print(f"❌ 비상정지 실패: {e}")
                return False


# ========================================
# Firebase 업데이트 함수
# ========================================
def update_status(status_text, indicator_class):
    """상태 업데이트"""
    try:
        db.reference('/status').set({
            'currentStatus': status_text,
            'indicatorClass': indicator_class,
            'timestamp': time.time()
        })
        print(f"📊 상태 업데이트: {status_text}")
    except Exception as e:
        print(f"❌ 상태 업데이트 실패: {e}")


def update_current_object(object_name):
    """현재 객체 업데이트"""
    try:
        db.reference('/currentObject').set({
            'name': object_name,
            'timestamp': time.time()
        })
        print(f"🎯 현재 객체: {object_name}")
    except Exception as e:
        print(f"❌ 객체 업데이트 실패: {e}")


# ========================================
# Firebase 명령 리스너
# ========================================

def command_listener(event):  # 인자 이름을 snapshot에서 event로 변경
    """Firebase에서 명령 수신"""
    global process_manager
    
    # [중요] listen() 모드에서는 event.data를 사용해야 합니다.
    commands = event.data
    
    if commands is None:
        return
    
    try:
        # 데이터가 딕셔너리 형태인지 확인
        if isinstance(commands, dict):
            # 가장 최신 명령 키 찾기
            latest_key = max(commands.keys())
            latest_command = commands[latest_key]
        else:
            return

        action = latest_command.get('action')
        timestamp = latest_command.get('timestamp', 0)
        
        # 시간 오차 허용 범위를 5초(5000ms)로 넉넉하게 설정
        current_time_ms = time.time() * 1000
        if current_time_ms - timestamp > 5000:
            return
        
        print(f"📥 명령 수신: {action}")
        
        if action == 'start':
            # 패키지명과 실행파일명을 실제 본인의 환경에 맞게 수정하세요.
            process_manager.start('kitchen_assistant', 'kitchen_voice')
        elif action == 'stop':
            process_manager.stop()
        elif action == 'emergency_stop':
            process_manager.emergency_stop()
        
        # 처리 완료 후 명령 삭제
        db.reference(f'/commands/{latest_key}').delete()
        
    except Exception as e:
        print(f"❌ 리스너 오류: {e}")
# def command_listener(snapshot):
#     """Firebase에서 명령 수신"""
#     global process_manager
    
#     if snapshot.val() is None:
#         return
    
#     # 가장 최근 명령 가져오기
#     # commands = snapshot.val()
    
#     # if not commands:
#     #     return

#     commands = event.data
    
#     if commands is None:
#         return
    
#     # # 최신 명령 찾기
#     # latest_key = max(commands.keys())
#     # latest_command = commands[latest_key]
    
#     # action = latest_command.get('action')
#     # timestamp = latest_command.get('timestamp', 0)
    
#     # # 1초 이내의 명령만 처리 (중복 실행 방지)
#     # if time.time() * 1000 - timestamp > 1000:
#     #     return
    
#     # print(f"📥 명령 수신: {action}")
    
#     # if action == 'start':
#     #     # ROS2 패키지와 실행 파일 이름 (여기를 실제 값으로 수정)
#     #     process_manager.start('kitchen_assistant', 'kitchen_voice')
        
#     # elif action == 'stop':
#     #     process_manager.stop()
        
#     # elif action == 'emergency_stop':
#     #     process_manager.emergency_stop()
    
#     # # 처리한 명령 삭제
#     # db.reference(f'/commands/{latest_key}').delete()

#     try:
#             # 데이터가 딕셔너리 형태인지 확인 (여러 명령이 쌓여있을 경우)
#             if isinstance(commands, dict):
#                 # 가장 최신 명령 키 찾기
#                 latest_key = max(commands.keys())
#                 latest_command = commands[latest_key]
#             else:
#                 # 데이터 구조가 단일 객체일 경우 처리
#                 return

#             action = latest_command.get('action')
#             timestamp = latest_command.get('timestamp', 0)
            
#             # [중요] 시간 동기화 문제 해결을 위해 오차 범위를 5초(5000ms)로 늘림
#             # 컴퓨터 시간과 서버 시간 차이 때문에 1초(1000)는 너무 타이트할 수 있습니다.
#             # current_time_ms = time.time() * 1000
#             # if current_time_ms - timestamp > 5000:
#             #     # print("⚠️ 오래된 명령 무시")
#             #     return
            
#             print(f"📥 명령 수신: {action}")
            
#             if action == 'start':
#                 process_manager.start('kitchen_assistant', 'kitchen_voice')
#             elif action == 'stop':
#                 process_manager.stop()
#             elif action == 'emergency_stop':
#                 process_manager.emergency_stop()
            
#             # 처리한 명령은 Firebase에서 삭제하여 중복 실행 방지
#             db.reference(f'/commands/{latest_key}').delete()
            
#     except Exception as e:
#         print(f"❌ 명령 처리 중 오류 발생: {e}")

# ========================================
# 메인 실행
# ========================================
def signal_handler(sig, frame):
    """Ctrl+C 처리"""
    print("\n\n👋 프로그램 종료 중...")
    if process_manager.is_running:
        process_manager.stop()
    sys.exit(0)


# 전역 변수
process_manager = ROS2ProcessManager()

def main():
    print("=" * 60)
    print("🤖 CoCooker")
    print("=" * 60)
    print("Ctrl+C로 종료하세요.")
    print("=" * 60)
    
    # Ctrl+C 핸들러 등록
    signal.signal(signal.SIGINT, signal_handler)
    
    # 초기 상태 설정
    update_status("대기 중", "")
    update_current_object("-")
    
    # Firebase 명령 리스너 시작
    db.reference('/commands').listen(command_listener)
    
    print("\n✅ 명령 대기 중...")
    
    # 무한 루프 (Firebase 리스너가 백그라운드에서 작동)
    try:
        while True:
            # 프로세스 상태 모니터링
            if process_manager.is_running and process_manager.process:
                poll = process_manager.process.poll()
                if poll is not None:
                    # 프로세스가 종료됨
                    process_manager.is_running = False
                    print(f"ℹ️ 프로세스 종료됨 (코드: {poll})")
                    update_status("완료", "")
                    update_current_object("작업 완료")
            
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n\n👋 프로그램 종료")
        if process_manager.is_running:
            process_manager.stop()


if __name__ == "__main__":
    main()
